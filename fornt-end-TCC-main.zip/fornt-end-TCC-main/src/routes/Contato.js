function Contato() {
    return (
      <div>
        <h2>Contato</h2>
      </div>
    );
  }
  
  export default Contato;